<?php

include('login-auth/config.php');

if(isset($_POST['submit'])){

    echo "yes";

}else{

    echo "no";

}



?>